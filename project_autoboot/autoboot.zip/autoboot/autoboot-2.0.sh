#! /bin/sh
echo "in autoboot-2.0.sh"
cd /autoboot
while read line
do
   basepath=$line
cd $basepath
jarStartSh=$(ls $basepath|grep start.sh)
jarFullName=$(ls $basepath|grep ".jar$")
if [ ${jarStartSh} ]
then
  printf "\n *************************正在启动${jarStartSh}*******************\n"
  sh start.sh
else
  printf "\n *******************没有找到start.sh,正在生成中*********************\n"
  cp -a /autoboot/config/*.sh ./
  sh start.sh
fi
echo ${jarFullName}" starting ... ... "
sleep 2
done < autoboot.txt
